import { chromium } from '/Users/bhavukarora/IdeaProjects/workout-starter/node_modules/playwright/index.mjs';

async function main() {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({
    viewport: { width: 1440, height: 960 },
    deviceScaleFactor: 2,
  });
  const page = await context.newPage();

  console.log('Navigating to http://localhost:3000 ...');
  await page.goto('http://localhost:3000', { waitUntil: 'networkidle' });
  await page.waitForTimeout(1000);

  const phoneElement = await page.$('.iphone-orange-bezel');

  // 1. Transition into Interval Mode by clicking the Start button on the phone
  console.log('Transitioning to interval...');
  await page.locator('button:has-text("All good")').first().click();
  await page.waitForTimeout(1000);

  if (phoneElement) {
    await phoneElement.screenshot({ path: 'screenshot-interval-athletic-phone.png' });
  }

  // 2. Click Adapt "My knee hurts" from the desktop preset
  console.log('Triggering knee adaptation...');
  await page.locator('button:has-text("My knee hurts")').first().click();
  
  // Capture thinking orb loading overlay
  await page.waitForTimeout(100);
  if (phoneElement) {
    await phoneElement.screenshot({ path: 'screenshot-thinking-orb-loading.png' });
  }
  await page.waitForTimeout(600);
  if (phoneElement) {
    await phoneElement.screenshot({ path: 'screenshot-knee-adapted-phone.png' });
  }

  // 3. Trigger Recovery mode
  console.log('Triggering recovery mode...');
  await page.locator('button:has-text("Need extra rest")').first().click();
  await page.waitForTimeout(800);
  if (phoneElement) {
    await phoneElement.screenshot({ path: 'screenshot-recovery-breath-phone.png' });
  }

  // 4. Trigger Debrief mode
  console.log('Triggering debrief mode...');
  await page.locator('button:has-text("Cooldown & Debrief")').first().click();
  await page.waitForTimeout(800);
  if (phoneElement) {
    await phoneElement.screenshot({ path: 'screenshot-debrief-phone.png' });
  }

  // 5. Open Builder Thesis Modal
  console.log('Opening Builder Thesis modal...');
  await page.locator('button:has-text("Builder Thesis")').first().click();
  await page.waitForTimeout(700);
  await page.screenshot({ path: 'screenshot-thesis-legal-verified.png' });

  await browser.close();
  console.log('All screenshots captured successfully!');
}

main().catch(console.error);
