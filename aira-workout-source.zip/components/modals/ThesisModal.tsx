'use client';

import React from 'react';
import ThesisLegalDocument from './ThesisLegalDocument';
import { WorkoutMode } from '../../types/workout';

interface ThesisModalProps {
  isOpen: boolean;
  onClose: () => void;
  onJumpToMode?: (mode: WorkoutMode) => void;
}

export default function ThesisModal({ isOpen, onClose }: ThesisModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-white animate-fadeIn font-sans">
      <ThesisLegalDocument onBackToWorkout={onClose} />
    </div>
  );
}
