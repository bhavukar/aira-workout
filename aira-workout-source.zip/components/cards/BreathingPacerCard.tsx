'use client';

import React, { useState, useEffect } from 'react';
import CrystalizedBall from '../ui/CrystalizedBall';

interface BreathingPacerCardProps {
  timerSeconds: number;
  onAddRest: () => void;
  onReadyToPush: () => void;
  formatTimer: (seconds: number) => string;
}

export default function BreathingPacerCard({
  timerSeconds,
  onAddRest,
  onReadyToPush,
  formatTimer,
}: BreathingPacerCardProps) {
  // Breathing cycle: Inhale (4s) -> Hold (4s) -> Exhale (4s)
  const [breathPhase, setBreathPhase] = useState<'Inhale' | 'Hold' | 'Exhale'>('Inhale');

  useEffect(() => {
    const interval = setInterval(() => {
      const sec = Math.floor(Date.now() / 1000) % 12;
      if (sec < 4) setBreathPhase('Inhale');
      else if (sec < 8) setBreathPhase('Hold');
      else setBreathPhase('Exhale');
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Compute ring size and speed dynamically per breath phase
  const ringSize = breathPhase === 'Inhale' ? 0.94 : breathPhase === 'Hold' ? 0.88 : 0.74;
  const ringSpeed = breathPhase === 'Inhale' ? 2.0 : breathPhase === 'Hold' ? 1.2 : 0.8;

  return (
    <div className="bg-white rounded-[32px] p-5 shadow-[0_4px_24px_rgba(0,0,0,0.03)] border border-black/5 space-y-4 font-sans animate-slide-up-fade">
      {/* Header */}
      <div className="flex items-center justify-between animate-slide-up-fade">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-sky-600 block mb-0.5">
            Rest Interval
          </span>
          <h2 className="text-xl font-black tracking-tight text-neutral-950 leading-tight">
            Guided Breathing
          </h2>
        </div>
        <span className="px-3 py-1 rounded-full bg-sky-50 text-sky-900 text-xs font-black font-mono">
          {formatTimer(timerSeconds)}
        </span>
      </div>

      {/* Hero CrystalizedBall Energy Ring */}
      <div className="py-2 flex flex-col items-center justify-center animate-scale-up-fade delay-150">
        <div className="relative w-44 h-44 flex items-center justify-center">
          {/* CrystalizedBall rendered as the electric perimeter energy ring */}
          <div className="absolute inset-0 flex items-center justify-center transition-transform duration-1000 ease-out">
            <CrystalizedBall
              preset="abyss"
              color="#0284C7"
              theme="light"
              size={ringSize}
              strands={5}
              crackle={0.55}
              flares={0.6}
              glow={0.9}
              sparks={0.4}
              particleCount={0}
              fill={0}
              motion="orbit"
              particleShape="round"
              depth={0.8}
              sway={0.8}
              haze={0.0}
              dustSpeed={0.9}
              speed={ringSpeed}
              interactive={true}
              hoverStrength={0.7}
            />
          </div>

          {/* Center phase text - clean and unobstructed */}
          <div className="relative z-10 flex flex-col items-center justify-center text-center select-none pointer-events-none">
            <span className="text-sm font-black text-neutral-950 uppercase tracking-widest leading-tight">
              {breathPhase}
            </span>
            <span className="text-[11px] text-sky-700 font-mono font-bold mt-0.5">
              4 seconds
            </span>
          </div>
        </div>

        <p className="text-xs text-neutral-500 text-center max-w-xs mt-2 leading-snug">
          Controlled breathing lowers your heart rate and prepares muscles for the next set.
        </p>
      </div>

      {/* Clean Metrics Row */}
      <div className="grid grid-cols-2 gap-2 text-xs animate-slide-up-fade delay-250">
        <div className="p-3 rounded-2xl bg-[#FAF9F5] border border-black/5">
          <span className="text-[10px] uppercase font-bold text-neutral-400 block">Heart Rate</span>
          <span className="text-sm font-black text-neutral-950 flex items-center gap-1.5 mt-0.5">
            <i className="bx bxs-heart text-red-500 text-sm"></i> 164 &rarr; 138 BPM
          </span>
        </div>
        <div className="p-3 rounded-2xl bg-[#FAF9F5] border border-black/5">
          <span className="text-[10px] uppercase font-bold text-neutral-400 block">Pacing Cadence</span>
          <span className="text-sm font-black text-neutral-950 flex items-center gap-1 mt-0.5">
            <i className="bx bx-time-five text-sky-600 text-base"></i> 4s In &middot; 4s Out
          </span>
        </div>
      </div>

      {/* Apple-Grade Action Buttons */}
      <div className="grid grid-cols-2 gap-2 pt-1 animate-slide-up-fade delay-350">
        <button
          onClick={onAddRest}
          className="py-3.5 px-4 rounded-full bg-neutral-100 hover:bg-neutral-200 border border-neutral-200/80 text-neutral-900 font-bold text-xs flex items-center justify-center gap-1.5 transition-all active:scale-95"
        >
          <i className="bx bx-plus text-base"></i> +20s Rest
        </button>
        <button
          onClick={onReadyToPush}
          className="py-3.5 px-4 rounded-full bg-[#141414] hover:bg-black text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all active:scale-95 shadow-xs"
        >
          Ready to Push <i className="bx bx-chevron-right text-base"></i>
        </button>
      </div>
    </div>
  );
}
